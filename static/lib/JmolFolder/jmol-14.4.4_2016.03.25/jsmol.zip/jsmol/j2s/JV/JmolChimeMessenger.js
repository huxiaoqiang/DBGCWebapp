Clazz.declarePackage ("JV");
Clazz.declareInterface (JV, "JmolChimeMessenger");
