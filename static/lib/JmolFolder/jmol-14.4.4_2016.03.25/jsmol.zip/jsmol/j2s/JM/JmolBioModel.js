Clazz.declarePackage ("JM");
Clazz.declareInterface (JM, "JmolBioModel");
